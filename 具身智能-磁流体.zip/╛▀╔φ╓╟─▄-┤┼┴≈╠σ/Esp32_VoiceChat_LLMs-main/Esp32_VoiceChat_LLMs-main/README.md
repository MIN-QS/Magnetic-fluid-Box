# Esp32_VoiceChat_LLMs
esp32 based device, mainly used for voice chat with large language models

bilibili：https://www.bilibili.com/video/BV1Xv421r715/?spm_id_from=333.999.0.0&vd_source=e90851eaa96a26b2d252237f9312b9f6

微信wechat：espai1024 


![a4](https://github.com/MetaWu2077/Esp32_VoiceChat_LLMs/assets/162696665/c3114871-2cf1-40fe-b856-1df43faf66b8)
![a2](https://github.com/MetaWu2077/Esp32_VoiceChat_LLMs/assets/162696665/a963ebf4-d87a-4ad5-af96-b4360837322d)
![a3](https://github.com/MetaWu2077/Esp32_VoiceChat_LLMs/assets/162696665/6bbf1532-1f90-4afe-8b9e-8970a6dbdd03)
